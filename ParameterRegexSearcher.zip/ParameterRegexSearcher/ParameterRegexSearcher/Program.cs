﻿using System;
using System.IO;
using System.Text.RegularExpressions;
using System.Collections.Generic;

// all logic is structured by tolga.f. AI is utilized only used for better logging 

class ParameterRegexSearcher
{
    // 🔹 Root directories for all solutions
    static List<string> solutionRoots = new List<string>
    {
        @"D:\tolga.f\BOA.BusinessModules\Dev\BOA.ERP.AIM",
        @"D:\tolga.f\BOA.BusinessModules\Dev\BOA.ERP.ASM",
        @"D:\tolga.f\BOA.BusinessModules\Dev\BOA.ERP.EstateSystem",
        @"D:\tolga.f\BOA.BusinessModules\Dev\BOA.ERP.ExpenseManagement",
        @"D:\tolga.f\BOA.BusinessModules\Dev\BOA.ERP.FAM",
        @"D:\tolga.f\BOA.BusinessModules\Dev\BOA.ERP.Invoice",
        @"D:\tolga.f\BOA.BusinessModules\Dev\BOA.ERP.LMS",
        @"D:\tolga.f\BOA.BusinessModules\Dev\BOA.ERP.LMSDefinition",
        @"D:\tolga.f\BOA.BusinessModules\Dev\BOA.ERP.POM"
    };

    static string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

    // 🔹 Map all constants: key = short name or full namespace, value = literal
    static Dictionary<string, string> constantMap = new(StringComparer.OrdinalIgnoreCase);

    static void Main()
    {
        string detailedPath = Path.Combine(desktopPath, "GetParameter_and_ParamType_Results.txt");
        string simplePath = Path.Combine(desktopPath, "ParamType_Only.txt");

        using StreamWriter detailedWriter = new(detailedPath, false);
        using StreamWriter simpleWriter = new(simplePath, false);

        detailedWriter.WriteLine("=== Detailed GetParameter + XAML ParamType ===");
        detailedWriter.WriteLine($"Started at: {DateTime.Now}");
        detailedWriter.WriteLine(new string('-', 80));

        simpleWriter.WriteLine("=== ParamType / GetParameter Only List ===");
        simpleWriter.WriteLine($"Started at: {DateTime.Now}");
        simpleWriter.WriteLine(new string('-', 80));

        foreach (var solutionRoot in solutionRoots)
        {
            detailedWriter.WriteLine($"\nScanning solution: {solutionRoot}");

            // 🔹 Build constant map from all CS files in the solution
            BuildConstantMap(solutionRoot);

            // 🔹 Search CS files for GetParameter
            SearchCsFiles(solutionRoot, detailedWriter, simpleWriter);

            // 🔹 Search XAML files for ParamType
            SearchXamlFiles(solutionRoot, detailedWriter, simpleWriter);
        }

        detailedWriter.WriteLine("\n✅ Scan completed successfully.");
        simpleWriter.WriteLine("\n✅ Scan completed successfully.");

        Console.WriteLine($"Detailed results: {detailedPath}");
        Console.WriteLine($"Simple results: {simplePath}");
    }

    // 🔹 Build map of constants from all CS files
    static void BuildConstantMap(string rootDir)
    {
        var constPattern = new Regex(@"\b(const|static\s+readonly|string|String|var)\s+([A-Za-z0-9_\.]+)\s*=\s*(""[^""]*"");", RegexOptions.Compiled);

        foreach (var file in Directory.GetFiles(rootDir, "*.cs", SearchOption.AllDirectories))
        {
            try
            {
                string content = File.ReadAllText(file);

                foreach (Match m in constPattern.Matches(content))
                {
                    string name = m.Groups[2].Value.Trim();   // e.g., OutlookUser
                    string value = m.Groups[3].Value.Trim();  // e.g., "OutlookUser"

                    if (!constantMap.ContainsKey(name))
                        constantMap[name] = value;

                    // 🔹 Also add full namespace if possible
                    string? namespacePrefix = GetNamespacePrefix(file);
                    if (!string.IsNullOrEmpty(namespacePrefix))
                    {
                        string fullName = namespacePrefix + "." + name;
                        if (!constantMap.ContainsKey(fullName))
                            constantMap[fullName] = value;
                    }
                }
            }
            catch { }
        }
    }

    // 🔹 Extract namespace/class prefix from CS file path
    static string? GetNamespacePrefix(string file)
    {
        try
        {
            string[] lines = File.ReadAllLines(file);
            foreach (var line in lines)
            {
                if (line.Trim().StartsWith("namespace "))
                {
                    string ns = line.Trim().Substring("namespace ".Length).Trim();
                    ns = ns.Split('{')[0].Trim();
                    return ns;
                }
            }
        }
        catch { }
        return null;
    }

    static void SearchCsFiles(string directory, StreamWriter detailedWriter, StreamWriter simpleWriter)
    {
        var regex = new Regex(@"\bGetParameter\s*\(\s*([^)]+)\s*\)", RegexOptions.Compiled);

        foreach (var file in Directory.GetFiles(directory, "*.cs"))
        {
            try
            {
                string[] lines = File.ReadAllLines(file);
                for (int i = 0; i < lines.Length; i++)
                {
                    foreach (Match match in regex.Matches(lines[i]))
                    {
                        string argsText = match.Groups[1].Value.Trim();

                        // 🔹 Split by comma outside quotes, take first argument
                        var args = Regex.Matches(argsText, @"(?<=^|,)\s*((""[^""]*"")|([^,]+))\s*(?=,|$)");
                        string firstArg = args.Count > 0 ? args[0].Value.Trim() : argsText;

                        string resolvedValue = ResolveArgument(firstArg);

                        detailedWriter.WriteLine($"[CS] {file} (line {i + 1}): {firstArg} => {resolvedValue}");

                        if (resolvedValue == "[NOT RESOLVED]")
                            simpleWriter.WriteLine($"{file}: {firstArg} => not resolved");
                        else
                            simpleWriter.WriteLine(resolvedValue);
                    }
                }
            }
            catch { }
        }

        foreach (var subdir in Directory.GetDirectories(directory))
        {
            SearchCsFiles(subdir, detailedWriter, simpleWriter);
        }
    }

    static void SearchXamlFiles(string directory, StreamWriter detailedWriter, StreamWriter simpleWriter)
    {
        var paramTypeRegex = new Regex(@"ParamType\s*=\s*""([^""]+)""", RegexOptions.Compiled);

        foreach (var file in Directory.GetFiles(directory, "*.xaml"))
        {
            try
            {
                string[] lines = File.ReadAllLines(file);

                for (int i = 0; i < lines.Length; i++)
                {
                    foreach (Match match in paramTypeRegex.Matches(lines[i]))
                    {
                        string paramTypeValue = match.Groups[1].Value.Trim();

                        // Detailed txt
                        detailedWriter.WriteLine($"[XAML] {file} (line {i + 1}): ParamType => \"{paramTypeValue}\"");

                        // Simple txt
                        if (string.IsNullOrWhiteSpace(paramTypeValue))
                            simpleWriter.WriteLine($"{file}: ParamType => not resolved");
                        else
                            simpleWriter.WriteLine($"\"{paramTypeValue}\"");
                    }
                }
            }
            catch { }
        }

        foreach (var subdir in Directory.GetDirectories(directory))
        {
            SearchXamlFiles(subdir, detailedWriter, simpleWriter);
        }
    }

    // 🔹 Recursive resolution: check full name first, then last part
    static string ResolveArgument(string arg)
    {
        if (arg.StartsWith("\"") && arg.EndsWith("\""))
            return arg;

        // Check full name first
        if (constantMap.TryGetValue(arg, out string? val))
        {
            if (!val.StartsWith("\""))
                return ResolveArgument(val);
            return val;
        }

        // Check last part (short name)
        if (arg.Contains('.'))
        {
            string[] parts = arg.Split('.');
            string last = parts[^1];
            if (constantMap.TryGetValue(last, out string? shortVal))
                return shortVal;
        }

        return "[NOT RESOLVED]";
    }
}