﻿using System.Text.RegularExpressions;
using Microsoft.Data.SqlClient;

// all logic is structured by tolga.f. AI is only used for better logging 
class RegexSearcher
{
    static string connectionString = "Server=D-DBMAIN;Database=BOA;Integrated Security=True;Encrypt=True;TrustServerCertificate=True;";

    static string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);

    // 🔹 Birden fazla root directory tanımlıyoruz
    static List<string> rootDirectories = new List<string>
    {
        @"D:\tolga.f\BOA.BusinessModules\Dev\BOA.ERP.AIM",
        @"D:\tolga.f\BOA.BusinessModules\Dev\BOA.ERP.ASM",
        @"D:\tolga.f\BOA.BusinessModules\Dev\BOA.ERP.EstateSystem",
        @"D:\tolga.f\BOA.BusinessModules\Dev\BOA.ERP.ExpenseManagement",
        @"D:\tolga.f\BOA.BusinessModules\Dev\BOA.ERP.FAM",
        @"D:\tolga.f\BOA.BusinessModules\Dev\BOA.ERP.Invoice",
        @"D:\tolga.f\BOA.BusinessModules\Dev\BOA.ERP.LMS",
        @"D:\tolga.f\BOA.BusinessModules\Dev\BOA.ERP.LMSDefinition",
        @"D:\tolga.f\BOA.BusinessModules\Dev\BOA.ERP.POM"


    };

    static HashSet<string> allNonExisting = new HashSet<string>();

    static void Main()
    {
        List<Regex> patterns = new List<Regex>
        {
            new Regex(@"\{m:Messaging\s+Group=(?<group>[^,]+),\s*Property=(?<property>[^\}]+)\}", RegexOptions.Compiled),
            new Regex(@"BOA\.Messaging\.MessagingHelper\.GetMessage\(\s*""(?<group>[^""]+)""\s*,\s*""(?<property>[^""]+)""\s*\)", RegexOptions.Compiled)
        };

        string outputPath = Path.Combine(desktopPath, "messaging_exact_matches_distinct.txt");
        string notExistPath = Path.Combine(desktopPath, "messaging_not_exist.txt");
        string allNonExistPath = Path.Combine(desktopPath, "all_messagings_non_exists.txt");

        Dictionary<string, bool> propertyExistenceMap = new Dictionary<string, bool>();

        using (StreamWriter writer = new(outputPath, false))
        using (StreamWriter notExistWriter = new(notExistPath, false))
        {
            writer.WriteLine("=== Messaging Pattern Search Results ===");
            writer.WriteLine($"Search started at: {DateTime.Now}");
            writer.WriteLine(new string('-', 80));

            notExistWriter.WriteLine("=== Not Exist Messaging Pattern Results (By Directory) ===");
            notExistWriter.WriteLine($"Search started at: {DateTime.Now}");
            notExistWriter.WriteLine(new string('-', 80));

            // 🔹 Her root klasörü sırayla tara
            foreach (var rootDir in rootDirectories)
            {
                writer.WriteLine($"\nScanning root: {rootDir}");
                notExistWriter.WriteLine($"\n### ROOT DIRECTORY: {rootDir}");

                SearchDirectory(rootDir, patterns, propertyExistenceMap, notExistWriter);
            }

            writer.WriteLine("\n=== Summary ===");
            foreach (var kvp in propertyExistenceMap)
            {
                writer.WriteLine($"{kvp.Key} - {(kvp.Value ? "exist" : "not exist")}");
            }

            writer.WriteLine("\n✅ Search completed successfully.");
            notExistWriter.WriteLine("\n✅ Search completed successfully.");
        }

        using (StreamWriter allWriter = new(allNonExistPath, false))
        {
            allWriter.WriteLine("=== ALL Non-Existing Messaging Keys ===");
            allWriter.WriteLine($"Generated at: {DateTime.Now}");
            allWriter.WriteLine(new string('-', 80));

            foreach (var item in allNonExisting)
                allWriter.WriteLine(item);

            allWriter.WriteLine("\n✅ Completed successfully.");
        }

        Console.WriteLine($"Results saved to: {outputPath}");
        Console.WriteLine($"Not exist results saved to: {notExistPath}");
        Console.WriteLine($"All non-existing results saved to: {allNonExistPath}");
    }

    static void SearchDirectory(string directory, List<Regex> patterns, Dictionary<string, bool> propertyExistenceMap, StreamWriter notExistWriter)
    {
        try
        {
            List<string> dirNonExisting = new List<string>();

            foreach (var file in Directory.GetFiles(directory))
            {
                if (file.EndsWith(".cs") || file.EndsWith(".xaml") || file.EndsWith(".config") || file.EndsWith(".xml"))
                {
                    SearchFileExactDistinct(file, patterns, propertyExistenceMap, dirNonExisting);
                }
            }

            if (dirNonExisting.Count > 0)
            {
                notExistWriter.WriteLine($"\n[DIRECTORY] {directory}");
                foreach (var item in dirNonExisting)
                {
                    notExistWriter.WriteLine($"  {item}");
                }
            }

            foreach (var subdir in Directory.GetDirectories(directory))
            {
                SearchDirectory(subdir, patterns, propertyExistenceMap, notExistWriter);
            }
        }
        catch { }
    }

    static void SearchFileExactDistinct(string filePath, List<Regex> patterns, Dictionary<string, bool> propertyExistenceMap, List<string> dirNonExisting)
    {
        try
        {
            string[] lines = File.ReadAllLines(filePath);

            foreach (string line in lines)
            {
                foreach (var regex in patterns)
                {
                    MatchCollection matches = regex.Matches(line);

                    foreach (Match match in matches)
                    {
                        string groupName = match.Groups["group"].Value.Trim();
                        string propertyName = match.Groups["property"].Value.Trim();

                        if (!string.IsNullOrEmpty(groupName) && !string.IsNullOrEmpty(propertyName))
                        {
                            string key = $"{groupName}:\"{propertyName}\"";

                            if (!propertyExistenceMap.ContainsKey(key))
                            {
                                bool exists = CheckPropertyNameExists(propertyName);
                                propertyExistenceMap[key] = exists;

                                if (!exists)
                                {
                                    dirNonExisting.Add(key);
                                    allNonExisting.Add(key);
                                }
                            }
                        }
                    }
                }
            }
        }
        catch { }
    }

    static bool CheckPropertyNameExists(string propertyName)
    {
        using var conn = new SqlConnection(connectionString);
        conn.Open();

        string query = "SELECT COUNT(1) FROM boa.cor.messaging WHERE propertyName = @propertyName";
        using (SqlCommand cmd = new(query, conn))
        {
            cmd.Parameters.AddWithValue("@propertyName", propertyName);
            int count = (int)cmd.ExecuteScalar();
            return count > 0;
        }
    }
}